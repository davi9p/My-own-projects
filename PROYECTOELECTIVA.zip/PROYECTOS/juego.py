import os
import random
import sys
import pygame

ANCHO_VIRTUAL, ALTO_VIRTUAL, ESCALA = 480, 320, 2
TAM_CASILLA, TAM_POKEMON, FPS = 32, 120, 90
FRAMES_ENTRADA, FRAMES_BARRA, FRAMES_POR_CUADRO = 45, 30, 8
SEGUNDOS_DESCANSO, SEGUNDOS_PASO = 2.5, 0.30
PROB_ENCUENTRO, PROB_HUIR = 0.35, 0.50
SUBIR_FONDO, ALTO_PANEL = 65, 76
POS_RIVAL, POS_JUGADOR = (310, 30), (60, 130)
MAX_NIVEL, XP_TOTAL = 100, 1_000_000
PUNTOS_POR_NIVEL, BONO_DECENA, HP_POR_NIVEL = 20, 5, 3

BLANCO, NEGRO, GRIS, ROJO = (255, 255, 255), (0, 0, 0), (60, 60, 60), (200, 50, 50)
VERDE_HP, AMARILLO_HP, AZUL_XP = (60, 200, 80), (240, 200, 40), (64, 140, 248)
COLOR_PANEL = (56, 64, 88)

ARRIBA, ABAJO = (pygame.K_UP, pygame.K_w), (pygame.K_DOWN, pygame.K_s)

DIRECCIONES = {"left": (-1, 0), "right": (1, 0), "back": (0, -1), "front": (0, 1)}

pygame.init()
pygame.mixer.init()
pantalla_real = pygame.display.set_mode((ANCHO_VIRTUAL * ESCALA, ALTO_VIRTUAL * ESCALA), pygame.RESIZABLE)
canvas = pygame.Surface((ANCHO_VIRTUAL, ALTO_VIRTUAL))
pygame.display.set_caption("¡Primeros pasos para llegar a ser el mejor en pokémon! - Ruta 1 y 2")

reloj = pygame.time.Clock()
fuente = pygame.font.SysFont("arial", 15)
fuente_grande = pygame.font.SysFont("arial", 14, bold=True)
BASE = os.path.dirname(os.path.abspath(__file__))


def cargar_sonido(ruta):
    return pygame.mixer.Sound(os.path.join(BASE, ruta))


def cargar_imagen(ruta, tamaño=None, alpha=True):
    img = pygame.image.load(os.path.join(BASE, ruta))
    img = img.convert_alpha() if alpha else img.convert()
    return pygame.transform.scale(img, tamaño) if tamaño else img

# icono de la ventana
pygame.display.set_icon(cargar_imagen("jugador/png/pokebola.png"))


SONIDO_OPCION = cargar_sonido("sonidos/opcionessonido.mp3")
SONIDO_INICIO = cargar_sonido("sonidos/sonidoparaentrarmenu.mp3")
SONIDO_GANAR = cargar_sonido("sonidos/ganarcombate.mp3")
SONIDO_ATAQUE = cargar_sonido("sonidos/sonidoataque.mp3")
SONIDO_PASTO = cargar_sonido("sonidos/caminandopasto.mp3")
SONIDO_ENCUENTRO = cargar_sonido("sonidos/encuentropokemon.mp3")
SONIDO_ENTRENADOR = cargar_sonido("sonidos/combateentrenadores.mp3")


def salir():
    pygame.quit()
    sys.exit()


def teclas():
    # lista de teclas que se apretaron
    pulsadas = []
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            salir()
        if evento.type == pygame.KEYDOWN:
            pulsadas.append(evento.key)
    return pulsadas


def actualizar_pantalla():
    pantalla_real.blit(pygame.transform.scale(canvas, pantalla_real.get_size()), (0, 0))
    pygame.display.flip()


def mostrar_pantalla():
    teclas()
    actualizar_pantalla()
    reloj.tick(FPS)


def mover(seleccion, tecla, cantidad):
    # sube o baja en el menú
    nuevo = seleccion
    if tecla in ARRIBA:
        nuevo = (seleccion - 1) % cantidad
    elif tecla in ABAJO:
        nuevo = (seleccion + 1) % cantidad
    if nuevo != seleccion:
        SONIDO_OPCION.play()
    return nuevo


def acercar(actual, objetivo, paso):
    if actual > objetivo:
        return max(objetivo, actual - paso)
    return min(objetivo, actual + paso)


def texto(sup, contenido, pos, color=NEGRO, grande=False):
    sup.blit((fuente_grande if grande else fuente).render(str(contenido), True, color), pos)


def dividir_texto(contenido, ancho):
    # parte el texto en líneas que quepan en el ancho
    lineas, actual = [], ""
    for palabra in contenido.split():
        prueba = (actual + " " + palabra).strip()
        if fuente.size(prueba)[0] <= ancho:
            actual = prueba
        else:
            lineas.append(actual)
            actual = palabra
    lineas.append(actual)
    return lineas


def caja(sup, rect, relleno=(248, 248, 216), borde=(112, 120, 128), grosor=2, radio=5):
    pygame.draw.rect(sup, relleno, rect, border_radius=radio)
    pygame.draw.rect(sup, borde, rect, grosor, border_radius=radio)


def boton(rect, contenido, activo):
    caja(canvas, rect, (248, 248, 216) if activo else (205, 210, 220), ROJO if activo else GRIS, 2, 6)
    img = fuente_grande.render(contenido, True, NEGRO)
    canvas.blit(img, img.get_rect(center=pygame.Rect(rect).center))


def barra(sup, x, y, proporcion, ancho, alto, color, radio=3):
    pygame.draw.rect(sup, (112, 120, 128), (x, y, ancho, alto), border_radius=radio)
    relleno = int(ancho * max(0, min(1, proporcion)))
    if relleno:
        pygame.draw.rect(sup, color, (x, y, relleno, alto), border_radius=radio)


def barra_hp(sup, x, y, hp, hp_max, ancho=95):
    # el color cambia según la vida
    prop = hp / hp_max if hp_max else 0
    color = VERDE_HP if prop > 0.5 else AMARILLO_HP if prop > 0.2 else ROJO
    texto(sup, "HP", (x, y - 1), (200, 160, 50))
    barra(sup, x + 20, y, prop, ancho - 20, 6, color)


def caja_info_rival(sup, x, y, p, hp):
    caja(sup, (x, y, 160, 45))
    texto(sup, p.nombre.upper(), (x + 8, y + 4), grande=True)
    texto(sup, f"Nv{p.nivel}", (x + 115, y + 4))
    barra_hp(sup, x + 8, y + 26, hp, p.hp_max, 140)


def caja_info_jugador(sup, x, y, p, hp):
    caja(sup, (x, y, 175, 70))
    texto(sup, p.nombre.upper(), (x + 12, y + 6), grande=True)
    texto(sup, f"Nv{p.nivel}", (x + 125, y + 6))
    barra_hp(sup, x + 40, y + 28, hp, p.hp_max, 120)
    texto(sup, f"{round(p.hp)}/{p.hp_max}", (x + 105, y + 40))
    barra(sup, x + 12, y + 60, p.progreso_xp, 151, 5, AZUL_XP, 2)


# nombre: (vida, ataque, frente, espalda, icono, evolución)
# las imágenes están en pokemones/imagenes
POKEDEX = {
    "Bulbasaur": (20, 5, "bulbasaurfront.png", "bulbasaurback.png", "bulbasauricono.png", "Ivysaur"),
    "Ivysaur": (30, 7, "ivysaurfront.png", "ivysaurback.png", "ivysauricono.png", "Venusaur"),
    "Venusaur": (40, 9, "venusaurfront.png", "venusaurback.png", "venusauricono.png", None),
    "Charmander": (20, 5, "charmanderfront.png", "charmanderback.png", "charmandericono.png", "Charmeleon"),
    "Charmeleon": (30, 7, "charmeleonfront.png", "charmeleonback.png", "charmeleonicono.png", "Charizard"),
    "Charizard": (40, 9, "charizardfront.png", "charizardback.png", "charizardicono.png", None),
    "Squirtle": (20, 5, "squirtlefront.png", "squirtleback.png", "squirtleicono.png", "Wartortle"),
    "Wartortle": (30, 7, "wartortlefront.png", "wartortleback.png", "wartortleicono.png", "Blastoise"),
    "Blastoise": (40, 9, "blastoisefront.png", "blastoiseback.png", "blastoiseicono.png", None),
    "Caterpie": (20, 5, "caterpiefront.png", "caterpie.png", "caterpieicono.png", "Metapod"),
    "Metapod": (30, 7, "metapodfront.png", "metapodback.png", "metapodicono.png", "Butterfree"),
    "Butterfree": (40, 9, "butterfreefront.png", "butterfreeback.png", "butterfreeicono.png", None),
    "Weedle": (20, 5, "weedlefront.png", "weedleback.png", "weedleicono.png", "Kakuna"),
    "Kakuna": (30, 7, "kakunafront.png", "kakunaback.png", "kakunaicono.png", "Beedrill"),
    "Beedrill": (40, 9, "beedrillfront.png", "beedrillback.png", "beedrillicono.png", None),
    "Pidgey": (20, 5, "pidgey_front.png", "pidgeyback.png", "pidgeyicono.png", "Pidgeotto"),
    "Pidgeotto": (30, 7, "pidgeottofront.png", "pidgeottoback.png", "pidgeottoicono.png", "Pidgeot"),
    "Pidgeot": (40, 9, "pidgeotfront.png", "pidgeotback.png", "pidgeoticono.png", None),
    "Rattata": (20, 5, "rattata_front.png", "rattataback.png", "rattataicono.png", "Raticate"),
    "Raticate": (30, 7, "raticatefront.png", "raticateback.png", "raticateicono.png", None),
    "Spearow": (20, 5, "spearowfront.png", "spearowback.png", "spearowicono.png", "Fearow"),
    "Fearow": (30, 7, "fearowfront.png", "fearowback.png", "fearowicono.png", None),
    "Ekans": (20, 5, "ekansfront.png", "ekansback.png", "ekansicono.png", "Arbok"),
    "Arbok": (30, 7, "arbokfront.png", "arbokback.png", "arbokicono.png", None),
    "Pikachu": (20, 5, "pikachufront.png", "pikachuback.png", "pikachuicono.png", "Raichu"),
    "Raichu": (30, 7, "raichufront.png", "raichuback.png", "raichuicono.png", None),
    "Sandshrew": (20, 5, "sandshrewfront.png", "sandshrewback.png", "sandshrewicono.png", "Sandslash"),
    "Sandslash": (30, 7, "sandslashfront.png", "sandslashback.png", "sandslashicono.png", None),
    "Nidoran-f": (20, 5, "nidoran-ffront.png", "nidoran-fback.png", "nidoran-ficono.png", "Nidorina"),
    "Nidorina": (30, 7, "nidorinafront.png", "nidorinaback.png", "nidorinaicono.png", "Nidoqueen"),
    "Nidoqueen": (40, 9, "nidoqueenfront.png", "nidoqueenback.png", "nidoqueenicono.png", None),
    "Nidoran-m": (20, 5, "nidoran-mfront.png", "nidoran-mback.png", "nidoran-micono.png", "Nidorino"),
    "Nidorino": (30, 7, "nidorinofront.png", "nidorinoback.png", "nidorinoicono.png", "Nidoking"),
    "Nidoking": (40, 9, "nidokingfront.png", "nidokingback.png", "nidokingicono.png", None),
    "Clefairy": (20, 5, "clefairyfront.png", "clefairyback.png", "clefairyicono.png", "Clefable"),
    "Clefable": (30, 7, "clefablefront.png", "clefableback.png", "clefableicono.png", None),
    "Vulpix": (20, 5, "vulpixfront.png", "vulpixback.png", "vulpixicono.png", "Ninetales"),
    "Ninetales": (30, 7, "ninetalesfront.png", "ninetalesback.png", "ninetalesicono.png", None),
    "Jigglypuff": (20, 5, "jigglyfront.png", "jigglyback.png", "jigglycono.png", "Wigglytuff"),
    "Wigglytuff": (30, 7, "wigglyfront.png", "wigglyback.png", "wigglyicono.png", None),
    "Zubat": (20, 5, "zubatfront.png", "zubatback.png", "zubaticono.png", "Golbat"),
    "Golbat": (30, 7, "golbatfront.png", "golbatback.png", "golbaticono.png", None),
    "Oddish": (20, 5, "oddishfront.png", "oddishback.png", "oddishicono.png", "Gloom"),
    "Gloom": (30, 7, "gloomfront.png", "gloomback.png", "gloomicono.png", "Vileplume"),
    "Vileplume": (40, 9, "vileplumefront.png", "vileplumeback.png", "vileplumeicono.png", None),
    "Paras": (20, 5, "parasfront.png", "parasback.png", "parasicono.png", "Parasect"),
    "Parasect": (30, 7, "parasectfront.png", "parasectback.png", "parasecticono.png", None),
    "Venonat": (20, 5, "venonatfront.png", "venonatback.png", "venonaticono.png", "Venomoth"),
    "Venomoth": (30, 7, "venomothfront.png", "venomothback.png", "venomothicono.png", None),
    "Diglett": (20, 5, "diglettfront.png", "diglettback.png", "diglettticono.png", "Dugtrio"),
    "Dugtrio": (30, 7, "Dugtriofront.png", "Dugtrioback.png", "Dugtrioicono.png", None),
}

POKEMONES_SALVAJES = list(POKEDEX)[:50]


SUMA_CUADRADOS = sum(n * n for n in range(1, MAX_NIVEL))


def xp_para_subir(nivel):
    return max(1, round(XP_TOTAL * nivel ** 2 / SUMA_CUADRADOS))


def puntos_de_victoria(rival):
    # en los niveles 10, 20, 30... da 5 veces más xp
    return rival.nivel * PUNTOS_POR_NIVEL * (BONO_DECENA if rival.nivel % 10 == 0 else 1)


class Pokemon:
    def __init__(self, nombre, nivel):
        self.nombre, self.nivel, self.xp = nombre, nivel, 0
        self.poner_datos()
        self.cargar_imagenes()

    def poner_datos(self):
        # saca vida, ataque y evolución de POKEDEX
        vida, ataque, _, _, _, self.evoluciona_a = POKEDEX[self.nombre]
        self.hp_max = vida + self.nivel * 5
        self.ataque = ataque + self.nivel * 2
        self.hp = self.hp_max

    def cargar_imagenes(self):
        frente, espalda, icono = POKEDEX[self.nombre][2:5]
        carpeta = "pokemones/imagenes/"
        grande = (TAM_POKEMON, TAM_POKEMON)
        imagenes = []

        for archivo, tamaño in ((frente, grande), (espalda, grande), (icono, (24, 24))):
            try:
                imagenes.append(cargar_imagen(carpeta + archivo, tamaño))
            except (FileNotFoundError, pygame.error):
                imagenes.append(pygame.Surface(tamaño, pygame.SRCALPHA))  # queda vacía

        self.imagen_frente, self.imagen_espalda, self.icono = imagenes

    @property
    def progreso_xp(self):
        return 1 if self.nivel >= MAX_NIVEL else self.xp / xp_para_subir(self.nivel)

    def esta_vivo(self):
        return self.hp > 0

    def curar(self):
        self.hp = self.hp_max

    def recibir_daño(self, cantidad):
        self.hp = max(0, self.hp - cantidad)

    def calcular_daño(self):
        return max(1, random.randint(self.ataque - 2, self.ataque + 2))

    def evolucionar(self):
        # cambia al pokémon por su evolución
        siguiente = self.evoluciona_a
        if siguiente not in POKEDEX:
            return None
        self.nombre = siguiente
        self.poner_datos()
        self.cargar_imagenes()
        return siguiente

    def ganar_xp(self, puntos):
        # sube de nivel y evoluciona si le toca
        subidos, evoluciones = 0, []
        if self.nivel >= MAX_NIVEL:
            return subidos, evoluciones

        self.xp += puntos
        while self.nivel < MAX_NIVEL and self.xp >= xp_para_subir(self.nivel):
            self.xp -= xp_para_subir(self.nivel)
            self.nivel += 1
            self.hp_max += HP_POR_NIVEL
            self.hp = min(self.hp_max, self.hp + HP_POR_NIVEL)
            subidos += 1
            evolucion = self.evolucionar()
            if evolucion:
                evoluciones.append(evolucion)

        if self.nivel >= MAX_NIVEL:
            self.xp = 0
        return subidos, evoluciones

    def dibujar(self, sup, x, y, de_espalda=False):
        sup.blit(self.imagen_espalda if de_espalda else self.imagen_frente, (x, y))


def generar_encuentro(jugador):
    # el nivel del salvaje depende del tuyo
    nv = jugador.criatura.nivel
    minimo = 1 if nv < 10 else nv // 10 * 10
    maximo = 9 if nv < 10 else min(minimo + 9, MAX_NIVEL)
    return Pokemon(random.choice(POKEMONES_SALVAJES), random.randint(minimo, maximo))


MAPA_RUTA_1 = [
    ["#",  "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3",  "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3","#"],
    ["#2", ".",  ".",  ".",  ".",  ".",  ".",  ".",  ".",   ".",  "P",  "P",  ".",  ".",  ".",  ".",  ".", ".", "#2"],
    ["#3", ".",  ".",  ".",  ".",  ".",  ".",  ".",  ".",   ".",  "P",  "P",  ".",  ".",  ".",  ".",  ".", ".", "#3"],
    ["#",  ".",  ".",  "P",  "P",  ".",  ".",  ".",  ".",   ".",  ".",  ".",  "P",  "P",  ".",  "P",  "P", ".", "."],
    ["#2", ".",  ".",  "P",  "P",  ".",  ".",  "a",  "a2",  "a3", ".",  ".",  "P",  "P",  ".",  "P",  "P", "E", ","],
    ["#3", ".",  ".",  ".",  ".",  ".",  ".",  "a1", "a22", "a33",".",  ".",  ".",  ".",  ".",  ".",  ".", "E2", ",1"],
    ["#",  ".",  ".",  ".",  ".",  ".",  ".",  "a11","a23", "a34",".",  ".",  ".",  ".",  ".",  ".",  ".", ".", "."],
    ["#2", ".",  ".",  "P",  "P",  ".",  ".",  ".",  ".",   ".",  ".",  ".",  ".",  "P",  "P",  ".",  ".", ".", "#"],
    ["#3", ".",  ".",  "P",  "P",  ".",  ".",  ".",  ".",   ".",  ".",  ".",  ".",  "P",  "P",  ".",  ".", ".", "#2"],
    ["#",  "#",  "#",  "#",  "#",  "#",  "#",  "#",  "#",   "#",  "#",  "#",  "#",  "#",  "#",  "#",  "#", "#", "#3"],
]

MAPA_RUTA_2 = [
    ["#",  "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3",  "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3", "#3","#"],
    ["#2", ".",  ".",  ".",  ".",  ".",  ".",  ".",  ".",   ".",  "P",  "P",  ".",  ".",  ".",  ".",  ".", ".", "#2"],
    ["#3", ".",  ".",  ".",  ".",  ".",  ".",  ".",  ".",   ".",  "P",  "P",  ".",  ".",  ".",  ".",  ".", ".", "#3"],
    [".",  ".",  ".",  "P",  "P",  ".",  ".",  ".",  ".",   ".",  ".",  ".",  "P",  "P",  ".",  ".",  ".", ".", "#"],
    [".",  ".",  ".",  "P",  "P",  ".",  "c",  "c2", "c3",  "c4", ".",  ".",  "P",  "P",  ".",  "P",  "P", ".", "#2"],
    [".",  ".",  ".",  ".",  ".",  ".",  "c1", "c22","c33", "c44",".",  ".",  ".",  ".",  ".",  "P",  "P", ".", "#3"],
    ["#",  ".",  ".",  "P",  "P",  ".",  "c11","c23","c34", "c45",".",  ".",  ".",  ".",  ".",  ".",  ".", ".", "#"],
    ["#2", ".",  ".",  "P",  "P",  ".",  ".",  ".",  ".",   ".",  ".",  ".",  ".",  ".",  ".",  ".",  ".", ".", "#2"],
    ["#3", "#",  "#",  "#",  "#",  "#",  "#",  "#",  "#",   "#",  "#",  "#",  "#",  "#",  "#",  "#",  "#", "#", "#3"],
    ]

MAPAS = {
    "ruta1": MAPA_RUTA_1,
    "ruta2": MAPA_RUTA_2
}

CONEXIONES = {
    ("ruta1", "right"): "ruta2",
    ("ruta2", "left"): "ruta1"
}

TAM_TILE = (TAM_CASILLA, TAM_CASILLA)


def tile_color(color, borde=None):
    tile = pygame.Surface(TAM_TILE)
    tile.fill(color)

    if borde:
        pygame.draw.rect(tile, borde, tile.get_rect(), 2)

    return tile


TERRENO = {
    ".": cargar_imagen("graficos/mapa/1.png", TAM_TILE),
    ",": cargar_imagen("graficos/mapa/sueloarriba.png", TAM_TILE),
    ",1": cargar_imagen("graficos/mapa/sueloabajo.png", TAM_TILE),
    "E": cargar_imagen("graficos/mapa/suelo1.png", TAM_TILE),
    "E2": cargar_imagen("graficos/mapa/suelo2.png", TAM_TILE),
    "P": cargar_imagen("graficos/mapa/ARBUSTO.png", TAM_TILE),
    "c": cargar_imagen("graficos/mapa/c.png", TAM_TILE),
    "c1": cargar_imagen("graficos/mapa/c1.png", TAM_TILE),
    "c11": cargar_imagen("graficos/mapa/c11.png", TAM_TILE),
    "c2": cargar_imagen("graficos/mapa/c2.png", TAM_TILE),
    "c22": cargar_imagen("graficos/mapa/c22.png", TAM_TILE),
    "c23": cargar_imagen("graficos/mapa/c23.png", TAM_TILE),
    "c3": cargar_imagen("graficos/mapa/c3.png", TAM_TILE),
    "c33": cargar_imagen("graficos/mapa/c33.png", TAM_TILE),
    "c34": cargar_imagen("graficos/mapa/c34.png", TAM_TILE),
    "c4": cargar_imagen("graficos/mapa/c4.png", TAM_TILE),
    "c44": cargar_imagen("graficos/mapa/c44.png", TAM_TILE),
    "c45": cargar_imagen("graficos/mapa/c45.png", TAM_TILE),
    "#": cargar_imagen("graficos/mapa/#.png", TAM_TILE),
    "#2": cargar_imagen("graficos/mapa/#2.png", TAM_TILE),
    "#3": cargar_imagen("graficos/mapa/#3.png", TAM_TILE),
    "a": cargar_imagen("graficos/mapa/a.png", TAM_TILE),
    "a1": cargar_imagen("graficos/mapa/a1.png", TAM_TILE),
    "a11": cargar_imagen("graficos/mapa/a11.png", TAM_TILE),
    "a2": cargar_imagen("graficos/mapa/a2.png", TAM_TILE),
    "a22": cargar_imagen("graficos/mapa/a22.png", TAM_TILE),
    "a23": cargar_imagen("graficos/mapa/a23.png", TAM_TILE),
    "a3": cargar_imagen("graficos/mapa/a3.png", TAM_TILE),
    "a33": cargar_imagen("graficos/mapa/a33.png", TAM_TILE),
    "a34": cargar_imagen("graficos/mapa/a34.png", TAM_TILE),

}

SOLIDOS = {"#", "#2", "#3", "a", "a1", "a11", "a2", "a22", "a23", "a3", "a33","a34","c","c1","c11", "c2", "c22", "c23", "c3", "c33", "c34", "c4", "c44", "c45"}


def dibujar_mapa(sup, mapa, cam_x, cam_y):
    for fila, linea in enumerate(mapa):
        for col, simbolo in enumerate(linea):
            sup.blit(TERRENO[simbolo], (col * TAM_CASILLA - cam_x, fila * TAM_CASILLA - cam_y))


def calcular_camara(jugador, mapa):
    # la cámara sigue al jugador
    cam_x = round(jugador.x) - (ANCHO_VIRTUAL - TAM_CASILLA) // 2
    cam_y = round(jugador.y) - (ALTO_VIRTUAL - TAM_CASILLA) // 2
    max_x = max(0, len(mapa[0]) * TAM_CASILLA - ANCHO_VIRTUAL)
    max_y = max(0, len(mapa) * TAM_CASILLA - ALTO_VIRTUAL)
    return max(0, min(cam_x, max_x)), max(0, min(cam_y, max_y))


fondo_batalla = cargar_imagen("graficos/mapa/BATALLA.png", (ANCHO_VIRTUAL, ALTO_VIRTUAL), False)

hoja_red = cargar_imagen("jugador/png/red_back_pic.png")
alto_cuadro = hoja_red.get_height() // 5
red_lanzamiento = [
    pygame.transform.scale(
        hoja_red.subsurface((0, i * alto_cuadro, hoja_red.get_width(), alto_cuadro)),
        (TAM_POKEMON, TAM_POKEMON))
    for i in range(5)
]


class Jugador:
    def __init__(self, pokemon_inicial):
        self.col, self.fila = 2, 2
        self.x, self.y = self.col * TAM_CASILLA, self.fila * TAM_CASILLA
        self.criatura = pokemon_inicial
        self.equipo = [pokemon_inicial]
        self.max_pokemones = 6
        self.mapa_actual = "ruta1"

        self.direccion = "front"
        self.moviendose = False
        self.progreso = 0.0
        self.destino = (self.col, self.fila)
        self.transicion = None
        self.pie = 1
        self.indice_frame = 0

        # imágenes de cada dirección: parado y dos pasos
        self.animaciones = {
            d: [cargar_imagen(f"jugador/png/red_{d}{s}.png", TAM_TILE) for s in ("", "move1", "move2")]
            for d in DIRECCIONES
        }

    def empezar_paso(self, destino, transicion=None):
        self.destino, self.transicion = destino, transicion
        self.moviendose, self.progreso = True, 0.0
        self.pie = 3 - self.pie
        self.indice_frame = self.pie

    def iniciar_paso(self, mapa, direccion):
        self.direccion = direccion
        dc, df = DIRECCIONES[direccion]
        col, fila = self.col + dc, self.fila + df

        # solo sale del mapa si hay conexión
        if not 0 <= col < len(mapa[0]):
            if (self.mapa_actual, direccion) in CONEXIONES:
                self.empezar_paso((col, fila), direccion)
            else:
                self.indice_frame = 0
            return

        # no pisa los sólidos
        if not 0 <= fila < len(mapa) or mapa[fila][col] in SOLIDOS:
            self.indice_frame = 0
            return

        # Blue también ocupa su casilla
        if (self.mapa_actual == "ruta2" and not RIVAL_BLUE.derrotado
                and (col, fila) in ((RIVAL_BLUE.col, RIVAL_BLUE.fila), RIVAL_BLUE.destino)):
            self.indice_frame = 0
            return

        if mapa[fila][col] == "P":
            SONIDO_PASTO.play()
        self.empezar_paso((col, fila))

    def avanzar(self, dt):
        # camina de a poco hasta la casilla
        self.progreso += dt / SEGUNDOS_PASO

        if self.progreso >= 1:
            self.col, self.fila = self.destino
            self.x, self.y = self.col * TAM_CASILLA, self.fila * TAM_CASILLA
            self.moviendose = False
            self.indice_frame = 0
            return True

        self.x = (self.col + (self.destino[0] - self.col) * self.progreso) * TAM_CASILLA
        self.y = (self.fila + (self.destino[1] - self.fila) * self.progreso) * TAM_CASILLA
        self.indice_frame = self.pie if self.progreso < 0.5 else 0
        return False

    def dibujar(self, sup, cam_x, cam_y):
        imagen = self.animaciones[self.direccion][self.indice_frame]
        sup.blit(imagen, (round(self.x) - cam_x, round(self.y) - cam_y + TAM_CASILLA - imagen.get_height()))


def direccion_hacia(dc, df):
    # nombre de la dirección para un paso (dc, df)
    for nombre, vector in DIRECCIONES.items():
        if vector == (dc, df):
            return nombre


class EntrenadorRival:
    def __init__(self, col, fila):
        # imágenes de cada dirección: parado y dos pasos
        ruta = "jugador/png/"
        self.imagenes = {
            "front": [cargar_imagen(ruta + "blue_front.png", TAM_TILE),
                      cargar_imagen(ruta + "blue_frontmove1.png", TAM_TILE),
                      cargar_imagen(ruta + "blue_frontmove2.png", TAM_TILE)],
            "back": [cargar_imagen(ruta + "blue_back.png", TAM_TILE),
                     cargar_imagen(ruta + "blue_backmove1.png", TAM_TILE),
                     cargar_imagen(ruta + "blue_backmove2.png", TAM_TILE)],
            "left": [cargar_imagen(ruta + "blue_left.png", TAM_TILE),
                     cargar_imagen(ruta + "blue_leftmove1.png", TAM_TILE),
                     cargar_imagen(ruta + "blue_leftmove2.png", TAM_TILE)],
            "right": [cargar_imagen(ruta + "blue_right.png", TAM_TILE),
                      cargar_imagen(ruta + "blue_rightmove1.png", TAM_TILE),
                      cargar_imagen(ruta + "blue_rightmove2.png", TAM_TILE)]
        }
        self.poner(col, fila)

    def poner(self, col, fila):
        self.col, self.fila = col, fila
        self.inicio = (col, fila)  # de aquí no se aleja más de 2 casillas
        self.x, self.y = col * TAM_CASILLA, fila * TAM_CASILLA
        self.direccion = "front"
        self.indice, self.pie = 0, 1
        self.destino = None  # casilla a la que camina, None si está quieto
        self.progreso = 0.0
        self.espera = 1.0
        self.derrotado = False

    def pasear(self, dt, mapa, jugador):
        # Blue se queda quieto un rato y luego da un paso al azar
        if self.destino is None:
            self.espera -= dt
            if self.espera > 0:
                return

            self.espera = random.uniform(1, 3)
            dc, df = random.choice(list(DIRECCIONES.values()))
            col, fila = self.col + dc, self.fila + df
            cerca = abs(col - self.inicio[0]) <= 2 and abs(fila - self.inicio[1]) <= 2

            if (cerca and 0 <= col < len(mapa[0]) and 0 <= fila < len(mapa)
                    and mapa[fila][col] not in SOLIDOS
                    and (col, fila) not in ((jugador.col, jugador.fila), jugador.destino)):
                self.destino, self.progreso = (col, fila), 0.0
                self.pie = 3 - self.pie
                self.direccion = direccion_hacia(dc, df)
            return

        self.progreso += dt / SEGUNDOS_PASO
        if self.progreso >= 1:
            self.col, self.fila = self.destino
            self.x, self.y = self.col * TAM_CASILLA, self.fila * TAM_CASILLA
            self.destino, self.indice = None, 0
        else:
            self.x = (self.col + (self.destino[0] - self.col) * self.progreso) * TAM_CASILLA
            self.y = (self.fila + (self.destino[1] - self.fila) * self.progreso) * TAM_CASILLA
            self.indice = self.pie if self.progreso < 0.5 else 0

    def dibujar(self, sup, cam_x, cam_y):
        sup.blit(self.imagenes[self.direccion][self.indice], (round(self.x) - cam_x, round(self.y) - cam_y))


RIVAL_BLUE = EntrenadorRival(10, 5)

SECUENCIA_BLUE = [1, 0, 2, 0]  # move1, parado, move2, parado

# nivel de los pokémon de Blue: cada 3 pokémon que tengas, sube al siguiente
NIVELES_BLUE = [4, 12, 25]


def regresar_inicio(jugador):
    # vuelve al inicio y cura al equipo
    jugador.mapa_actual = "ruta1"
    jugador.col, jugador.fila = 2, 2
    jugador.x, jugador.y = 2 * TAM_CASILLA, 2 * TAM_CASILLA
    jugador.destino = (2, 2)
    jugador.transicion = None
    jugador.moviendose, jugador.progreso = False, 0

    for pokemon in jugador.equipo:
        pokemon.curar()
    RIVAL_BLUE.poner(10, 5)


def buscar_camino_blue(jugador):
    # camino de Blue hasta quedar junto al jugador
    mapa = MAPAS["ruta2"]
    inicio, objetivo = (RIVAL_BLUE.col, RIVAL_BLUE.fila), (jugador.col, jugador.fila)
    pendientes, visitados = [(inicio, [])], {inicio}

    while pendientes:
        (col, fila), camino = pendientes.pop(0)
        if abs(col - objetivo[0]) + abs(fila - objetivo[1]) == 1:
            return camino

        for dc, df in DIRECCIONES.values():
            nueva = (col + dc, fila + df)
            if (0 <= nueva[0] < len(mapa[0]) and 0 <= nueva[1] < len(mapa)
                    and nueva not in visitados
                    and mapa[nueva[1]][nueva[0]] not in SOLIDOS
                    and nueva != objetivo):
                visitados.add(nueva)
                pendientes.append((nueva, camino + [nueva]))

    return None


def blue_ve_al_jugador(jugador):
    # Blue te ve si estás en su misma columna, hasta 3 casillas arriba o abajo, sin sólidos en medio
    if (jugador.mapa_actual != "ruta2" or RIVAL_BLUE.derrotado or jugador.moviendose
            or RIVAL_BLUE.destino is not None or jugador.col != RIVAL_BLUE.col):
        return False

    if not 1 <= abs(jugador.fila - RIVAL_BLUE.fila) <= 3:
        return False

    paso = 1 if jugador.fila > RIVAL_BLUE.fila else -1
    return all(MAPAS["ruta2"][f][jugador.col] not in SOLIDOS
               for f in range(RIVAL_BLUE.fila + paso, jugador.fila, paso))


def acercar_blue(jugador):
    # Blue camina hasta quedar junto al jugador
    camino = buscar_camino_blue(jugador)
    if camino is None:
        return False

    caminado = 0
    for col, fila in camino:
        inicio_x, inicio_y = RIVAL_BLUE.x, RIVAL_BLUE.y
        fin_x, fin_y = col * TAM_CASILLA, fila * TAM_CASILLA
        tiempo = 0
        RIVAL_BLUE.direccion = direccion_hacia(col - RIVAL_BLUE.col, fila - RIVAL_BLUE.fila)

        while tiempo < SEGUNDOS_PASO:
            tiempo = min(tiempo + reloj.tick(FPS) / 1000, SEGUNDOS_PASO)
            RIVAL_BLUE.x = inicio_x + (fin_x - inicio_x) * tiempo / SEGUNDOS_PASO
            RIVAL_BLUE.y = inicio_y + (fin_y - inicio_y) * tiempo / SEGUNDOS_PASO
            caminado += reloj.get_time() / 1000
            RIVAL_BLUE.indice = SECUENCIA_BLUE[int(caminado / 0.1) % 4]  # cambia de imagen cada 0.1 s
            dibujar_mundo(jugador)
            actualizar_pantalla()
            teclas()

        RIVAL_BLUE.col, RIVAL_BLUE.fila = col, fila
        RIVAL_BLUE.x, RIVAL_BLUE.y = fin_x, fin_y

    RIVAL_BLUE.indice = 0  # se queda parado
    return True


def frente_a_blue(jugador):
    # true si el jugador está junto a Blue y mirándolo
    return (jugador.mapa_actual == "ruta2" and not RIVAL_BLUE.derrotado
            and not jugador.moviendose and RIVAL_BLUE.destino is None
            and DIRECCIONES[jugador.direccion] == (RIVAL_BLUE.col - jugador.col, RIVAL_BLUE.fila - jugador.fila))


def dibujar_mundo(jugador):
    mapa = MAPAS[jugador.mapa_actual]
    cam_x, cam_y = calcular_camara(jugador, mapa)

    canvas.fill(NEGRO)
    dibujar_mapa(canvas, mapa, cam_x, cam_y)
    if jugador.mapa_actual == "ruta2" and not RIVAL_BLUE.derrotado:
        RIVAL_BLUE.dibujar(canvas, cam_x, cam_y)
    jugador.dibujar(canvas, cam_x, cam_y)
    texto(canvas, "P: MENÚ", (ANCHO_VIRTUAL - 65, 5), BLANCO)
    if frente_a_blue(jugador):
        texto(canvas, "ENTER: hablar", (10, 5), BLANCO)


def mostrar_dialogo(mensajes):
    # si el mensaje es largo se divide en líneas, y ENTER pasa a lo que sigue
    paginas = []
    for mensaje in mensajes:
        lineas = dividir_texto(mensaje, 370)
        for i in range(0, len(lineas), 3):
            paginas.append(lineas[i:i + 3])

    indice = 0
    while indice < len(paginas):
        if pygame.K_RETURN in teclas():
            SONIDO_OPCION.play()
            indice += 1
            if indice == len(paginas):
                break

        y = ALTO_VIRTUAL - ALTO_PANEL + 6
        caja(canvas, (8, y, ANCHO_VIRTUAL - 16, 64), (40, 48, 64), BLANCO, 3, 6)
        for n, linea in enumerate(paginas[indice]):
            texto(canvas, linea, (18, y + 22 - 9 * (len(paginas[indice]) - 1) + n * 18), BLANCO)
        texto(canvas, "▼ ENTER", (ANCHO_VIRTUAL - 75, y + 42), (200, 200, 200))
        actualizar_pantalla()
        reloj.tick(FPS)


def pelear_con_blue(jugador):
    # Blue te mira, habla y pelea con entre 2 y 6 pokémon al azar
    RIVAL_BLUE.direccion = direccion_hacia(jugador.col - RIVAL_BLUE.col, jugador.fila - RIVAL_BLUE.fila)
    RIVAL_BLUE.indice = 0
    mostrar_dialogo([
        "Hey mani qué, todo bien?",
        "Mano, me dijeron que andas con la vuelta de los pokemones, vamos a darnos un combate, si o qué?"
    ])

    nivel = NIVELES_BLUE[min(len(jugador.equipo) // 3, len(NIVELES_BLUE) - 1)]
    equipo_blue = [Pokemon(random.choice(POKEMONES_SALVAJES), nivel) for _ in range(random.randint(2, 6))]
    if combate(jugador, equipo_blue[0], True, equipo_blue[1:]) == "gano":
        RIVAL_BLUE.derrotado = True


def mostrar_menu():
    seleccion = 0
    fondo = cargar_imagen("graficos/mapa/MENUjpeg.jpeg", (ANCHO_VIRTUAL, ALTO_VIRTUAL), False)
    pygame.mixer.music.load(os.path.join(BASE, "sonidos/menu.mp3"))
    pygame.mixer.music.play(-1)

    while True:
        for tecla in teclas():
            seleccion = mover(seleccion, tecla, 2)
            if tecla == pygame.K_RETURN:
                if seleccion == 1:
                    salir()
                SONIDO_INICIO.play()
                pygame.time.wait(600)
                pygame.mixer.music.stop()
                return

        canvas.blit(fondo, (0, 0))
        boton(((ANCHO_VIRTUAL - 160) // 2, 140, 160, 40), "INICIAR", seleccion == 0)
        boton(((ANCHO_VIRTUAL - 160) // 2, 195, 160, 40), "SALIR", seleccion == 1)
        mostrar_pantalla()


def pantalla_descanso():
    # pantalla negra de descanso
    canvas.fill(NEGRO)
    img = fuente_grande.render("Tomando un descanso...", True, BLANCO)
    canvas.blit(img, img.get_rect(center=(ANCHO_VIRTUAL // 2, ALTO_VIRTUAL // 2)))
    for _ in range(int(SEGUNDOS_DESCANSO * FPS)):
        mostrar_pantalla()


def menu_equipo(jugador, durante_combate=False):
    # ENTER pone de primero (en combate lo elige)
    seleccion = 0

    while True:
        for tecla in teclas():
            elegido = jugador.equipo[seleccion]

            if tecla in (pygame.K_ESCAPE, pygame.K_p, pygame.K_BACKSPACE):
                return None

            if tecla in ARRIBA + ABAJO:
                seleccion = mover(seleccion, tecla, len(jugador.equipo))

            elif tecla == pygame.K_RETURN:
                if durante_combate:
                    if elegido.esta_vivo():
                        return elegido
                elif elegido.esta_vivo() and seleccion != 0:
                    jugador.equipo.remove(elegido)
                    jugador.equipo.insert(0, elegido)
                    jugador.criatura = elegido
                    seleccion = 0

            elif durante_combate and pygame.K_1 <= tecla <= pygame.K_6:
                indice = tecla - pygame.K_1
                if indice < len(jugador.equipo) and jugador.equipo[indice].esta_vivo():
                    return jugador.equipo[indice]

        canvas.fill((40, 64, 88))
        texto(canvas, "POKÉMONES", (20, 15), BLANCO, True)

        for i, pokemon in enumerate(jugador.equipo):
            y = 55 + i * 39
            activo = i == seleccion
            caja(canvas, (18, y, 444, 33), (248, 248, 216) if activo else (205, 210, 220),
                 ROJO if activo else GRIS, 2, 4)
            canvas.blit(pokemon.icono, (30, y + 4))

            estado = f"PS {pokemon.hp}/{pokemon.hp_max}" if pokemon.esta_vivo() else "Debilitado"
            texto(canvas, f"{i + 1}. {pokemon.nombre}  Nv.{pokemon.nivel}  {estado}", (62, y + 9))

            if pokemon is jugador.criatura:
                texto(canvas, "EN CAMPO", (370, y + 9), (30, 100, 50))

        texto(canvas, "ENTER: elegir  |  ESC: volver" if durante_combate
              else "ENTER: poner de primero  |  ESC: volver", (20, 292), BLANCO)
        mostrar_pantalla()


def menu_principal_juego(jugador):
    opciones = ["POKÉMONES", "DESCANSAR", "SALIR DEL JUEGO"]
    seleccion = 0

    while True:
        for tecla in teclas():
            if tecla in (pygame.K_ESCAPE, pygame.K_p):
                return

            seleccion = mover(seleccion, tecla, len(opciones))

            if tecla == pygame.K_RETURN:
                if seleccion == 0:
                    menu_equipo(jugador)
                elif seleccion == 1:
                    for pokemon in jugador.equipo:
                        pokemon.curar()
                    pantalla_descanso()
                    return
                else:
                    salir()

        canvas.fill((40, 64, 88))
        texto(canvas, "MENÚ", (20, 20), BLANCO, True)
        for i, opcion in enumerate(opciones):
            boton((90, 85 + i * 55, 300, 42), opcion, i == seleccion)
        texto(canvas, "Flechas: mover | ENTER: aceptar | P: cerrar", (20, 285), BLANCO)
        mostrar_pantalla()


def combate(jugador, salvaje, es_entrenador=False, rivales=None):
    # devuelve: gano, perdio, capturo o huyo
    # rivales: los pokémon que le quedan a Blue después del primero
    rivales = rivales or []
    mio = jugador.criatura
    mensaje = "¡Combate contra Blue!" if es_entrenador else f"¡Un {salvaje.nombre} salvaje apareció!"
    turno_jugador, barras_listas, resultado = True, True, None
    vida_salvaje, vida_mia = salvaje.hp, mio.hp

    def dibujar_escena(con_cajas=True, red=None, mostrar_mio=True):
        canvas.fill(COLOR_PANEL)
        canvas.blit(fondo_batalla, (0, -SUBIR_FONDO))
        salvaje.dibujar(canvas, *POS_RIVAL)
        if red:
            canvas.blit(red, POS_JUGADOR)
        if mostrar_mio:
            mio.dibujar(canvas, *POS_JUGADOR, de_espalda=True)
        pygame.draw.rect(canvas, COLOR_PANEL, (0, ALTO_VIRTUAL - ALTO_PANEL, ANCHO_VIRTUAL, ALTO_PANEL))

        if not con_cajas:
            return

        caja_info_rival(canvas, 15, 15, salvaje, vida_salvaje)
        caja_info_jugador(canvas, 290, 155, mio, vida_mia)

        y = ALTO_VIRTUAL - ALTO_PANEL + 6
        caja(canvas, (8, y, 292, 64), (40, 48, 64), BLANCO, 3, 6)
        lineas = dividir_texto(mensaje, 270)[:3]
        for n, linea in enumerate(lineas):
            texto(canvas, linea, (18, y + 22 - 9 * (len(lineas) - 1) + n * 18), BLANCO)
        caja(canvas, (308, y, 164, 64), grosor=3, radio=6)
        for i, opcion in enumerate(("1. ATACAR", "2. ATRAPAR", "3. POKÉMONES", "4. HUIR")):
            texto(canvas, opcion, (317, y + 2 + i * 14))

    def lanzar_red(cuadros):
        for cuadro in red_lanzamiento:
            for _ in range(cuadros):
                dibujar_escena(False, cuadro, False)
                mostrar_pantalla()

    def enviar(nuevo):
        nonlocal mio, vida_mia, mensaje
        mio = jugador.criatura = nuevo
        vida_mia = mio.hp
        lanzar_red(FRAMES_POR_CUADRO)
        mensaje = f"¡Adelante, {mio.nombre}!"

    musica = SONIDO_ENTRENADOR if es_entrenador else SONIDO_ENCUENTRO
    musica.play()

    # entrada del combate
    for f in range(FRAMES_ENTRADA + 1):
        suave = 1 - (1 - f / FRAMES_ENTRADA) ** 3
        xr = int(ANCHO_VIRTUAL + (POS_RIVAL[0] - ANCHO_VIRTUAL) * suave)
        xred = int(-TAM_POKEMON + (POS_JUGADOR[0] + TAM_POKEMON) * suave)

        canvas.fill(COLOR_PANEL)
        canvas.blit(fondo_batalla, (0, -SUBIR_FONDO))
        salvaje.dibujar(canvas, xr, POS_RIVAL[1])
        canvas.blit(red_lanzamiento[0], (xred, POS_JUGADOR[1]))
        mostrar_pantalla()

    lanzar_red(FRAMES_POR_CUADRO)

    # cada vuelta del while es un cuadro del combate
    while True:
        for tecla in teclas():
            # solo actúa en su turno
            if not (turno_jugador and barras_listas and resultado is None
                    and salvaje.esta_vivo() and mio.esta_vivo()):
                continue

            if tecla in (pygame.K_1, pygame.K_KP1):  # atacar
                SONIDO_ATAQUE.play()
                daño = mio.calcular_daño()
                salvaje.recibir_daño(daño)
                mensaje = f"{mio.nombre} atacó ({daño} daño)."
                turno_jugador = False

            elif tecla in (pygame.K_2, pygame.K_KP2):  # atrapar
                if not es_entrenador and len(jugador.equipo) < jugador.max_pokemones:
                    # con poca vida es más fácil atraparlo
                    proporcion = salvaje.hp / salvaje.hp_max
                    probabilidad = min(0.90, max(0.20, 0.25 + (1 - proporcion) * 0.65))
                    lanzar_red(FRAMES_POR_CUADRO // 2)

                    if random.random() < probabilidad:
                        jugador.equipo.append(salvaje)
                        resultado = "capturo"
                        mensaje = f"¡Capturaste a {salvaje.nombre}!"
                    else:
                        mensaje = "¡Se liberó de la Pokébola!"
                        turno_jugador = False

            elif tecla in (pygame.K_3, pygame.K_KP3):  # cambiar de pokémon
                elegido = menu_equipo(jugador, True)
                if elegido and elegido is not mio:
                    enviar(elegido)
                    turno_jugador = False

            elif tecla in (pygame.K_4, pygame.K_KP4):  # huir
                if not es_entrenador:
                    if random.random() < PROB_HUIR:
                        resultado = "huyo"
                        mensaje = "¡Escapaste del combate!"
                    else:
                        mensaje = "¡No pudiste escapar!"
                        turno_jugador = False

        # las barras de vida bajan de a poco
        vida_salvaje = acercar(vida_salvaje, salvaje.hp, max(1, salvaje.hp_max / FRAMES_BARRA))
        vida_mia = acercar(vida_mia, mio.hp, max(1, mio.hp_max / FRAMES_BARRA))
        barras_listas = vida_salvaje == salvaje.hp and vida_mia == mio.hp

        # revisa si alguien se debilitó
        if resultado is None and barras_listas:
            if not salvaje.esta_vivo():
                puntos = puntos_de_victoria(salvaje)
                mensaje = f"+{puntos} XP"
                subidos, evoluciones = mio.ganar_xp(puntos)
                if subidos:
                    mensaje += f" ¡Subió al nivel {mio.nivel}!"
                if evoluciones:
                    mensaje += f" ¡Evolucionó a {evoluciones[-1]}!"

                if rivales:  # a Blue le quedan pokémon
                    salvaje = rivales.pop(0)
                    vida_salvaje = salvaje.hp
                    mensaje += f" ¡Blue sacó a {salvaje.nombre}!"
                    turno_jugador = True
                else:
                    resultado = "gano"
                    SONIDO_GANAR.play()
                    mensaje = "¡Ganaste! " + mensaje

            elif not mio.esta_vivo():
                vivos = [p for p in jugador.equipo if p.esta_vivo()]
                if vivos:  # entra el siguiente
                    mensaje = f"¡{mio.nombre} se debilitó!"
                    dibujar_escena()
                    mostrar_pantalla()
                    pygame.time.wait(900)
                    enviar(vivos[0])
                    turno_jugador = True
                else:
                    resultado = "perdio"
                    mensaje = "¡Todo tu equipo cayó!"

            elif not turno_jugador:  # turno del rival
                daño = salvaje.calcular_daño()
                mio.recibir_daño(daño)
                mensaje = f"{salvaje.nombre} contraatacó ({daño} daño)."
                turno_jugador, barras_listas = True, False

        dibujar_escena()
        mostrar_pantalla()

        # fin del combate
        if resultado is not None:
            musica.stop()  # corta el sonido
            pygame.time.wait(1200)
            if es_entrenador:
                mostrar_dialogo(["Joda mano, tas claro que fue bastante bueno el combate", "Nos veremos!"])
            if resultado == "perdio":
                pantalla_descanso()
                regresar_inicio(jugador)
            return resultado


def fila_transitable(mapa, fila, col):
    # busca una fila libre
    for distancia in range(len(mapa)):
        for f in (fila - distancia, fila + distancia):
            if 0 <= f < len(mapa) and mapa[f][col] not in SOLIDOS:
                return f
    return fila


def cambiar_mapa(jugador):
    nuevo = CONEXIONES[(jugador.mapa_actual, jugador.transicion)]
    mapa = MAPAS[nuevo]

    # entra por el lado contrario
    if jugador.transicion == "right":
        col_entrada, jugador.col = 0, -1
    else:
        col_entrada, jugador.col = len(mapa[0]) - 1, len(mapa[0])

    if nuevo == "ruta2":
        RIVAL_BLUE.poner(10, 5)  # Blue reaparece cada vez que entras a la ruta 2

    jugador.fila = fila_transitable(mapa, jugador.fila, col_entrada)
    jugador.mapa_actual = nuevo
    jugador.x, jugador.y = jugador.col * TAM_CASILLA, jugador.fila * TAM_CASILLA
    jugador.empezar_paso((col_entrada, jugador.fila))


def main():
    # menú de inicio y bucle del juego
    mostrar_menu()
    jugador = Jugador(Pokemon("Pikachu", 5))
    dt = 0.0

    while True:
        for tecla in teclas():
            if tecla == pygame.K_ESCAPE:
                salir()
            if tecla == pygame.K_p and not jugador.moviendose:
                menu_principal_juego(jugador)
                dt = 0
            if tecla == pygame.K_RETURN and frente_a_blue(jugador):
                pelear_con_blue(jugador)
                dt = 0

        # al llegar a una casilla: cambia de mapa o sale un pokémon
        if jugador.moviendose and jugador.avanzar(dt):
            if jugador.transicion is not None:
                cambiar_mapa(jugador)
            elif (MAPAS[jugador.mapa_actual][jugador.fila][jugador.col] == "P"
                  and random.random() < PROB_ENCUENTRO and jugador.criatura.esta_vivo()):
                combate(jugador, generar_encuentro(jugador))
                dt = 0

        # camina con las flechas
        if not jugador.moviendose:
            pulsadas = pygame.key.get_pressed()
            mapa = MAPAS[jugador.mapa_actual]

            if pulsadas[pygame.K_LEFT]:
                jugador.iniciar_paso(mapa, "left")
            elif pulsadas[pygame.K_RIGHT]:
                jugador.iniciar_paso(mapa, "right")
            elif pulsadas[pygame.K_UP]:
                jugador.iniciar_paso(mapa, "back")
            elif pulsadas[pygame.K_DOWN]:
                jugador.iniciar_paso(mapa, "front")

        # Blue te ve desde su columna, camina hasta ti y pelean; si no, pasea
        if jugador.mapa_actual == "ruta2" and not RIVAL_BLUE.derrotado:
            if blue_ve_al_jugador(jugador) and acercar_blue(jugador):
                pelear_con_blue(jugador)
                dt = 0
            else:
                RIVAL_BLUE.pasear(dt, MAPAS["ruta2"], jugador)

        dibujar_mundo(jugador)
        actualizar_pantalla()
        dt = min(reloj.tick(FPS) / 1000, 0.05)


if __name__ == "__main__":
    main()